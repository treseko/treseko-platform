Executions and evidence are intentionally not included.
