# Generación de casos manuales

Workflow oficial portable Treseko Universal v2. La importación crea un borrador modificable y no lo activa.
