# Generación de casos manuales v2

Workflow oficial portable Treseko Universal v2. La importación crea un borrador modificable y no lo activa.
